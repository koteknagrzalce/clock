let g, p;
let secondsRadius;
let minutesRadius;
let hoursRadius;
let clockDiameter;

function setup() {
  createCanvas(720, 400);
  stroke(255);

  let radius = min(width, height) / 2;
  secondsRadius = radius * 0.71;
  minutesRadius = radius * 0.6;
  hoursRadius = radius * 0.5;
  clockDiameter = radius * 1.7;

  g = width / 2;
  p = height / 2;
}

function draw() {
  background(230);

  // rysuje tlo zegaraka
  noStroke();
  fill(244, 122, 158);
  ellipse(g, p, clockDiameter + 25, clockDiameter + 25);
  fill(237, 34, 93);
  ellipse(g, p, clockDiameter, clockDiameter);

  
  let sec = map(second(), 0, 60, 0, TWO_PI) - HALF_PI;
  let min = map(minute() + norm(second(), 0, 60), 0, 60, 0, TWO_PI) - HALF_PI;
  let god = map(hour() + norm(minute(), 0, 60), 0, 24, 0, TWO_PI * 2) - HALF_PI;

  // 
  stroke(255);
  strokeWeight(1);
  line(g, p, g + cos(sec) * secondsRadius, p + sin(sec) * secondsRadius);
  strokeWeight(2);
  line(g, p, g + cos(min) * minutesRadius, p + sin(min) * minutesRadius);
  strokeWeight(4);
  line(g, p, g + cos(god) * hoursRadius, p + sin(god) * hoursRadius);

  // rysuje znaczniki minut
  strokeWeight(2);
  beginShape(POINTS);
  for (let a = 0; a < 360; a += 6) {
    let angle = radians(a);
    let x = g + cos(angle) * secondsRadius;
    let y = p + sin(angle) * secondsRadius;
    vertex(x, y);
  }
  endShape();
}
